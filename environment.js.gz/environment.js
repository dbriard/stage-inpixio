const environment = "Development";
export {environment};
